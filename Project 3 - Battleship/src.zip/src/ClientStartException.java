public class ClientStartException extends Exception {
    public ClientStartException(String message) {
        super(message);
    }
}
